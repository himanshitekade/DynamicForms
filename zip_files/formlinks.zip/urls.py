from django.urls import path
from <your application name> import views



urlpatterns = [
    path('formlinks/', views.FormLinksView.as_view(), name='formlinks'),

]