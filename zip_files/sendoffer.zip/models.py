from django.db import models
from phonenumber_field.modelfields import PhoneNumberField
import datetime

class SendOffer (models.Model):
	status_code = models.BooleanField(default=1)
	offer_attachment = models.FileField(upload_to='sendoffer_attachment',blank=True, null=True)
	user = models.CharField(max_length=100, blank=True, null=True)
	date = models.DateField(blank=True, null=True)
	apply_negotiation = models.CharField(max_length=100, blank=True, null=True)
	text_field_1 = models.CharField(max_length=100, blank=True, null=True)
	text_field_2 = models.CharField(max_length=100, blank=True, null=True)
	int_field_1 = models.IntegerField(default=0, blank=True, null=True)
	int_field_2 = models.IntegerField(default=0, blank=True, null=True)
	float_field_1 = models.CharField(max_length=100, blank=True, null=True)
	float_field_2 = models.CharField(max_length=100, blank=True, null=True)
	datetime_field_1 = models.DateTimeField(blank=True, null=True)
	datetime_field_2 = models.DateTimeField(blank=True, null=True)
	