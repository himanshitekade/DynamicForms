from django.urls import path
from <your application name> import views



urlpatterns = [
    path('sendoffer/', views.SendOffer View.as_view(), name='sendoffer'),

]