'''
Date of creation: 18:23:09 15-03-2024
Created by: USER NAME 
'''

from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.views import View
from .models import *
from datetime import datetime
from django.contrib import messages
import json
from django.db.models import Q
import os
from django.core.paginator import Paginator



class SendOffer View(View):

	def __init__(self,*args,**kwargs):
		path = os.getcwd()

		with open(os.path.join(path, "form_jsons/SendOffer.json"), 'r') as file:
			self.queryset = file.read()

	def get(self,request,*args, **kwargs):
		file = self.queryset 
		queryset_dict = json.loads(file)

		action = request.GET.get('action',None)
		instance_id = request.GET.get('id',None)
		search = request.GET.get('search',None)
		entries = request.GET.get('entries', '5')

		table_values = queryset_dict['HTML_table']['values']
		list_table_values = [x["name"] for x in table_values]
		
		if action == 'create':	
			context = {
				"redirect":"sendoffer"
			}       
			return render(request, 'create.html', context)

		elif action == 'edit':
			if instance_id:
				data = SendOffer .objects.filter(status=1).get(id=instance_id)

				date_date = datetime.strftime(data.date, '%Y-%m-%d')
				date_date_obj = datetime.strptime(date_date,'%Y-%m-%d')

				dtime_datetime_field_1 = data.datetime_field_1.strftime('%Y-%m-%dT%H:%M')
				dtime_datetime_field_1_obj = datetime.strptime(dtime_datetime_field_1, '%Y-%m-%dT%H:%M')

				dtime_datetime_field_2 = data.datetime_field_2.strftime('%Y-%m-%dT%H:%M')
				dtime_datetime_field_2_obj = datetime.strptime(dtime_datetime_field_2, '%Y-%m-%dT%H:%M')

				

				json_string = str(queryset_dict)
				context = {"data":data, "redirect":"sendoffer", 'date_date': date_date, 'dtime_datetime_field_1': dtime_datetime_field_1,'dtime_datetime_field_2': dtime_datetime_field_2,}
				return render(request,'edit.html',context)

		elif action == 'delete':	
			if instance_id:
				return self.delete(request)

		elif action == 'search':
			data = SendOffer .objects.filter(Q(offer_attachment__icontains=search)|Q(user__icontains=search)|Q(date__icontains=search)|Q(apply_negotiation__icontains=search)|Q(text_field_1__icontains=search)|Q(text_field_2__icontains=search)|Q(int_field_1__icontains=search)|Q(int_field_2__icontains=search)|Q(float_field_1__icontains=search)|Q(float_field_2__icontains=search)|Q(datetime_field_1__icontains=search)|Q(datetime_field_2__icontains=search),status=1).all()

			paginator = Paginator(data, int(entries)) 
			page_number = request.GET.get('page')
			page_obj = paginator.get_page(page_number)
			pagination_url = request.path + "?entries=" + entries + "&search=" + search + "&action=" + action + "&"

			#TODO: Uncomment if checkbox field is included in the form.
			#for i in data:
				#var =i.checkbox.replace("[","")
				#var = var.replace("]","")
				#var = var.replace("'", "")
				#var = var.split(",")
				#i.checkbox = var
				#i.save()

			context = {
				"data":data, 
				"values":table_values, 
				"JsonForm": queryset_dict, 
				"redirect":"sendoffer",
				"entries" : entries,
				"page_obj" : page_obj,
                "pagination_url" : pagination_url,
				}
			return render(request,'table.html',context)

		else:    						
			data = SendOffer .objects.filter(status = 1).only(*list_table_values)


			paginator = Paginator(data, int(entries)) 
			page_number = request.GET.get('page')
			page_obj = paginator.get_page(page_number)

			if action:
				pagination_url = request.path + "?entries=" + entries + "&action=" + action + "&"          
			else:
				pagination_url = request.path + "?entries=" + entries + "&"


			#TODO: Uncomment if checkbox field is included in the form.
			
			#for i in data:
				#var =i.checkbox.replace("[","")
				#var = var.replace("]","")
				#var = var.replace("'", "")
				#var = var.split(",")
				#i.checkbox = var
				#i.save()

			context = {
				"data":data,
				"redirect":"sendoffer",
				"values":table_values,
				"JsonForm": queryset_dict,
				"entries" : entries,
				"page_obj" : page_obj,
               	"pagination_url" : pagination_url
			}
			return render(request,'table.html',context)

    # Create
	def post(self,request,*args, **kwargs):
		if '_put' in request.POST:
			return self.put(request)
			
		
		offer_attachment = request.FILES.get('offer_attachment',None)
		user = request.POST.get('user', None)
		date = request.POST.get('date', None)
		apply_negotiation = request.POST.get('apply_negotiation', None)
		text_field_1 = request.POST.get('text_field_1', None)
		text_field_2 = request.POST.get('text_field_2', None)
		int_field_1 = request.POST.get('int_field_1', None)
		int_field_2 = request.POST.get('int_field_2', None)
		float_field_1 = request.POST.get('float_field_1', None)
		float_field_2 = request.POST.get('float_field_2', None)
		datetime_field_1 = request.POST.get('datetime_field_1', None)
		datetime_field_2 = request.POST.get('datetime_field_2', None)
		
		
		data = SendOffer .objects.create(offer_attachment = offer_attachment, user = user, date = date, apply_negotiation = apply_negotiation, text_field_1 = text_field_1, text_field_2 = text_field_2, int_field_1 = int_field_1, int_field_2 = int_field_2, float_field_1 = float_field_1, float_field_2 = float_field_2, datetime_field_1 = datetime_field_1, datetime_field_2 = datetime_field_2, )

		if data:
			return redirect('sendoffer')

    # Edit
	def put(self,request,*args,**kwargs):
		
		offer_attachment = request.FILES.get('offer_attachment',None)
		user = request.POST.get('user', None)
		date = request.POST.get('date', None)
		apply_negotiation = request.POST.get('apply_negotiation', None)
		text_field_1 = request.POST.get('text_field_1', None)
		text_field_2 = request.POST.get('text_field_2', None)
		int_field_1 = request.POST.get('int_field_1', None)
		int_field_2 = request.POST.get('int_field_2', None)
		float_field_1 = request.POST.get('float_field_1', None)
		float_field_2 = request.POST.get('float_field_2', None)
		datetime_field_1 = request.POST.get('datetime_field_1', None)
		datetime_field_2 = request.POST.get('datetime_field_2', None)
		
		id   = request.POST.get('id',None)

		#TODO: Implement IF validation if file field available in the form

		#if file:
			#obj = SendOffer .objects.get(id=id)
			#'''obj.offer_attachment= offer_attachment
			'''
			#obj.save()
			
		# TODO: Remove file field
		update = SendOffer .objects.filter(id=id).update(offer_attachment = offer_attachment, user = user, date = date, apply_negotiation = apply_negotiation, text_field_1 = text_field_1, text_field_2 = text_field_2, int_field_1 = int_field_1, int_field_2 = int_field_2, float_field_1 = float_field_1, float_field_2 = float_field_2, datetime_field_1 = datetime_field_1, datetime_field_2 = datetime_field_2, )
		
		#else: 
		#	old_data = SendOffer .objects.get(id=id)

		#	update = SendOffer .objects.filter(id=id).update(offer_attachment = offer_attachment, user = user, date = date, apply_negotiation = apply_negotiation, text_field_1 = text_field_1, text_field_2 = text_field_2, int_field_1 = int_field_1, int_field_2 = int_field_2, float_field_1 = float_field_1, float_field_2 = float_field_2, datetime_field_1 = datetime_field_1, datetime_field_2 = datetime_field_2, )

		if update:
			return redirect('sendoffer')
		else:
			return HttpResponse("Not updated")

    # Delete
	def delete(self,request,*args,**kwargs):
		id = request.GET.get('id',None)

		update = SendOffer .objects.filter(id=id).update(status=0)
		if update:
			return redirect('sendoffer')
		else:
			return HttpResponse("Not updated")


